# simpleJDB

simpleJDB is a simple python databse.